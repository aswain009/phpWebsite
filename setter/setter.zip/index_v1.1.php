<?php
if ($_SERVER['REMOTE_ADDR'] != '75.109.54.26') {
    //exit();
}

//WHILE BUILDING
//error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ALL);
//ini_set('display_errors', 1);

require ('inc/config.php');
require ('inc/functions.php');
require ('inc/initialize.php');
require ('autoloader.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rego Manufacturing</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="container main">


    <div class="row header">
        <div class="col-xs-4">
            <?php if(isset($_GET['column'])): ?>
                <h3 class="data-header">Data: <?php echo $_GET['column'];?></h3>
            <?php else: ?>
                <h3 class="data-header">Data:</h3>
            <?php endif; ?>
        </div>
        <div class="col-xs-8">
            <ul class="nav nav-pills pull-right ">

                <li role="presentation" <?php echo $active1;?>><a href="?view=1">All</a></li>
                <li role="presentation" <?php echo $active2;?>><a href="?view=2">Individual</a></li>
                <li role="presentation" <?php echo $active3;?>><a href="?view=3">Code</a></li>

            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">

            <?php echo $output;?>

        </div>
    </div>

</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="footer"><strong>Rego Manufacturing</strong> - Custom Built by <a href="http://ohiowebpro.com" target="_blank">Ohio Web Pro Design, LLC</a></p>
        </div>
    </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/flot/jquery.flot.min.js"></script>
<script src="js/flot/jquery.flot.resize.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!--<script src="js/bootstrap.min.js"></script>-->
<!-- Include custom scripting -->
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>

<script>
<?php if(isset($js)): ?>
<?php echo $js; ?>
<?php endif; ?>
</script>


</body>
</html>