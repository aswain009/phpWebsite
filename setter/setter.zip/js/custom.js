jQuery(function($){

	//Code Page Datepickers
	$( "#start-month" ).datepicker({
		maxDate: new Date(), //Set the max date to today for the start month

		onSelect: function(date){
			var selectedDate = new Date(date);
			selectedDate.setDate(selectedDate.getDate() - 1); //Then set the end month restriction so it will only be days prior to the selected start date

			$('#end-month').datepicker('option', 'maxDate', selectedDate);
		}
	});

	//The default value of the max date is yesterday
	var endMaxDate = new Date();
	endMaxDate.setDate(endMaxDate.getDate() - 1);

	$( "#end-month" ).datepicker({
		maxDate: endMaxDate
	});
})