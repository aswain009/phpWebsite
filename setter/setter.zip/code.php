<?php
$active1 = '';
$active2 = '';
$active3 = 'active';

require_once('inc/head.php');
require_once('inc/header.php'); 

use setter\SetProd;
use setter\Setter;

$setterFeed = Setter::readAll(); ?>

<form id="date-change" method="POST" action="code.php">
	<label for="start-month" title="This must be higher than the end date">Start Month</label>
	<input type="text" name="startDate" id="start-month" class="datepick" />

	<label for="end-month" title="This must be lower than the start date">End Month</label>
	<input type="text" name="endDate" id="end-month" class="datepick" />

	<label for="no-months" title="This will be ignored if an end date is set">Number of Months</label>
	<input type="number" name="noMonths" id="no-months" min="1" max="20" value="12" />

	<input type="submit" class="btn btn-default btn-sm" value="View" />
</form><!--#date-change-->

<div class="row two-months">

<?php //Go through the current (or at a specific starting point) and the number of months requested

//This will determine the number of months to display
//The end date supercedes the month counter


if(isset($_POST['endDate']) && !empty($_POST['endDate'])){
	$endDateObj = (new DateTime($_POST['endDate']))->modify('first day of this month');

	//var_dump($endDateObj); echo '<br/>';

	//Mostly to get the calculations to compare the start date and end date

	//Make sure there is a start date
	if(isset($_POST['startDate']) && !empty($_POST['startDate'])){
		//Get the start date
		$startDateObj = (new DateTime($_POST['startDate']))->modify('first day of this month');
	} else {
		//If no start date set then use the current month
		$startDateObj = (new DateTime())->modify('first day of this month'); 
	}

	//var_dump($startDateObj); echo '<br/>';

	$months = abs((int)$startDateObj->diff($endDateObj)->format('%m') + 1);

	//var_dump($months); echo '<br/>';

} else {
	if(isset($_POST['noMonths']) && $_POST['noMonths'] > 0){
		$months = $_POST['noMonths'];
	} else {
		$months = 12;
	}
}

//Accumulation of all code totals
$totals = array();
$sorts = SetProd::readAllCodes(); //Set up an array to sort the setting and stones separaterly

//Initialize the sortedTotal array with the pre-sorted settings and stones array keys
foreach($sorts as $sort){
	$sortedTotal[$sort['SetCode']] = array();
}

for($i = 0; $i < $months; $i++){
	//Set the starting and last dates.
	if(isset($_POST['startDate']) && !empty($_POST['startDate'])){
		$dateObj = new DateTime($_POST['startDate']);
		$dateObj->modify('-'.$i.' months');
	} else {
		$dateObj = new DateTime('-'.$i.' months');
	}
	
	$startDate = $dateObj->format('Y-m-01 00:00:00'); //First day of the month
	$endDate = $dateObj->format('Y-m-t 23:59:59'); //Last day of the month

	//Get the colspan count for the <thead> 
	$colspan = count($setterFeed); ?>

	<table class="monthly-code">
		<thead>
			<tr>
				<th colspan="<?=$colspan; ?>"><?=$dateObj->format('F, Y'); ?></th>
			</tr>
		</thead>

		<?php //Setup data for making table rows
		$tbodyHeader = array(); //Initialize the first row of the <tbody> which displays the names
		$tbodyHeader['0'] = ''; //The first element is a blank since the column is going to be for the code names

		foreach($sorts as $sort){
			$sorted[$sort['SetCode']] = array();
		}

		//var_dump($sorted);

		foreach($setterFeed as $setter){

			//Make the first tbody row, the first names of the setters
			$spacePosition = strpos($setter->getName(), ' '); //Find the first space ' ' between first and last name
			$tbodyHeader[$setter->getSetterNo()] = substr($setter->getName(), 0, $spacePosition);

			//Get all one setters data based on date range (first day of the month to the last day of the month)
			$setProdFeed = SetProd::readBySetterDateRange($setter, $startDate, $endDate);
			

			//Make sure feed is not empty
			if($setProdFeed !== false){

				foreach($setProdFeed as $setProd){

					if(isset($sorted[$setProd->getSetCode()][$setProd->getSetterNo()])){
						$sorted[$setProd->getSetCode()][$setProd->getSetterNo()] += ( $setProd->getQtySet() - $setProd->getQtyBk() );
					} else {
						$sorted[$setProd->getSetCode()][$setProd->getSetterNo()] = ( $setProd->getQtySet() - $setProd->getQtyBk() );
					}

					if(isset($sortedTotal[$setProd->getSetCode()][$setProd->getSetterNo()])){
						$sortedTotal[$setProd->getSetCode()][$setProd->getSetterNo()] += ( $setProd->getQtySet() - $setProd->getQtyBk() );	
					} else {
						$sortedTotal[$setProd->getSetCode()][$setProd->getSetterNo()] = ( $setProd->getQtySet() - $setProd->getQtyBk() );
					}
					
				}
			}
		} ?>

		<tbody>
			<?php //Name row ?>
			<tr>
				<?php foreach($tbodyHeader as $name): ?>
					<td><?=$name; ?></td>
				<?php endforeach; ?>
			</tr>

			<?php //Code rows ?>
			<?php foreach($sorted as $code => $data): 
				if(count($data)): ?>
					<tr>
						<td><?=$code; ?></td>
						<?php foreach($tbodyHeader as $no => $name): ?>
							<?php if($no != '0'): //Though reusing the tbodyHeader array; we need to ignore the dummy '0' array
								if(isset($data[$no])): ?>
									<td><?=$data[$no]; ?></td>
								<?php else: ?>
									<td>0</td>
								<?php endif; ?>
							<?php endif; ?>
						<?php endforeach; ?>
					</tr>
				<?php endif;
			endforeach; ?>
		</tbody>
	</table><!--.monthly-code-->

	<?php if($i % 2 == 1): ?>
		</div><!--.row-->
		<div class="row two-months">
	<?php endif;
} ?>

</div><!--.row-->

<div class="totals row">
	<table class="total-code">
		<thead>
			<tr>
				<th colspan="<?=$colspan; ?>">Total</th>
			</tr>
		</thead>
		<tbody>
			<?php //Name row ?>
			<tr>
				<?php foreach($tbodyHeader as $name): ?>
					<td><?=$name; ?></td>
				<?php endforeach; ?>
			</tr>

			<?php //Code rows ?>
			<?php foreach($sortedTotal as $code => $data): 
				if(count($data)): ?>
					<tr>
						<td><?=$code; ?></td>
						<?php foreach($tbodyHeader as $no => $name): ?>
							<?php if($no != '0'): //Though reusing the tbodyHeader array; we need to ignore the dummy '0' array
								if(isset($data[$no])): ?>
									<td><?=$data[$no]; ?></td>
								<?php else: ?>
									<td>0</td>
								<?php endif; ?>
							<?php endif; ?>
						<?php endforeach; ?>
					</tr>
				<?php endif;
			endforeach; ?>
		</tbody>
	</table><!--.col-md-4-->
</div><!--.totals-->

<?php require_once('inc/footer.php'); ?>