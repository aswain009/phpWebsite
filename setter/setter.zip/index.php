<?php
$active1 = 'active';
$active2 = '';
$active3 = '';

require_once('inc/head.php');
require_once('inc/header.php');

use setter\SetBase;
use setter\Setter;

$setterFeed = Setter::readAll();
foreach($setterFeed as $setter){
    $setters[$setter->getSetterNo()] = $setter->getName();
}

if (!isset($_GET['column'])) {
    $columnType = 'Total';
} else {
    $columnType = $_GET['column'];
}

if (isset($_GET['number'])) {
    $noPeriods =  $_GET['number'];
} else {
    $noPeriods = 12;
}

//set period titles
if (isset($_GET['period']) && $_GET['period'] == "Monthly") {
    $periodTitle = 'Month';
    $periodType = 'Monthly';
} else {
    $periodTitle = 'Week';
    $periodType = 'Weekly';
}

if (isset($_GET['setbase']) && $_GET['setbase'] == 'true') {
    $notice = setBase($_GET['setterNo'],$_GET['baseline_date'],$_GET['baseline_value']);
}

$columnChoice = array ('Total', 'Hrs', 'OThrs', 'Qty', 'Amt', 'Brk', 'Bamt', 'AQ', 'AA');
$periodChoice = array ('Weekly', 'Monthly');

//Lets first check to see if the period is monthly or a weekly (default)
if(isset($periodType) && $periodType == "Monthly"){
    //MONTHLY
    if(!empty($_GET['startdate'])){ //check if date is set
        //var_dump($_GET['startdate']);
        $startdate = DateTime::createFromFormat('m/d/Y', $_GET['startdate']);
        $startdate->modify('first day of this month');

        $prevdate = clone $startdate;
        $prevdate->modify('-1 month');
        $nextdate = clone $startdate;
        $nextdate->modify('+1 month');
        $chartdate = clone $startdate;
        $chartdate->modify('next month');
    } else { //the date is default
        $startdate = new DateTime;
        $startdate->modify('first day of this month');
        $prevdate = clone $startdate;
        $prevdate->modify('-1 month'); //originally -2 months
        $nextdate = clone $startdate;
        $nextdate->modify('+1 month'); //originally not modified
        $chartdate = clone $startdate;
        $chartdate->modify('next month');
    }
} else {
    //WEEKLY
    if(!empty($_GET['startdate'])){ //check if date is set
        $startdate = DateTime::createFromFormat('m/d/Y', $_GET['startdate']);
        $startdate->modify('monday this week');
        $prevdate = clone $startdate;
        $prevdate->modify('-7 day');
        $nextdate = clone $startdate;
        $nextdate->modify('+7 day');
        $chartdate = clone $startdate;
        $chartdate->modify('next week');
    } else {
        $startdate = new DateTime;
        $startdate->modify('monday this week');
        $prevdate = clone $startdate;
        $prevdate->modify('-7 day'); //originally -14 days
        $nextdate = clone $startdate;
        $nextdate->modify('+7 day'); //originally not modified
        $chartdate = clone $startdate;
        $chartdate->modify('next week');
    }
}

//var_dump($startdate); echo ' - start<br/>';
//var_dump($prevdate); echo ' - prev<br/>';
//var_dump($nextdate); echo '- next<br/>';
//var_dump($chartdate); echo '- chart<br/>'; //go ahead a month or week for chart data

$page = '';
$range = array();
$weekTotal = array();
$weekHours = array();
$header = array();
$setterData = array();
$numberSetters = array();

$onePeriodData = array();
$fourPeriodData = array();
$twelvePeriodData = array();

//All setters except Misc Setter
foreach($setters as $setterID => $setter){

    $pageset = '';
    $ifsetterhas = '';
    $pageset.=  '<tr class="chartLoad" id="'.$setterID.'"><td class="settername">'.$setter.' <span class="glyphicon glyphicon-wrench baseSet"></span></td>';

    $range['firstday'] = $chartdate->format('m/d/Y');
    
    $BaseDaily = 0;
    $BaseHours = 0;

    //i represent the period
    for($i=1; $i <= $noPeriods; $i++) {

        $setterData[$setterID][$i] = $setterData;
        if(isset($_GET['period']) && $_GET['period'] == "Monthly") {
            $range = get_month_before($range['firstday']);
        } else {
            $range = get_week_before($range['firstday']);
        }

        $header[$i] = $range['firstday'];

        //Get the data of a setter
        //$alldata = get_setter_data($range['firstday'], $range['lastday'], $setterID, $columnType);
        $alldata = \setter\SetBase::readData($setterID, $range['firstday'], $range['lastday'], $columnType);
        $setterVal = $alldata->columnTotal; //Value for table chart


        //Construct the baseline
        if((float)$alldata->dailyHours){
            $setterBaseData[$setterID][$i] = $alldata->adjDailyBase / $alldata->dailyHours;
        } else {
            $setterBaseData[$setterID][$i] = 0;
        }

        //Then accumulate a total baseline of all setters
        if(isset($setterBaselineTotal[$i]['AdjDailyBase'])){
            $setterBaselineTotal[$i]['AdjDailyBase'] += $alldata->adjDailyBase;    
        } else {
            $setterBaselineTotal[$i]['AdjDailyBase'] = $alldata->adjDailyBase;
        }

        if(isset($setterBaselineTotal[$i]['DailyHrs'])){
            $setterBaselineTotal[$i]['DailyHrs'] += $alldata->dailyHours;
        } else {
            $setterBaselineTotal[$i]['DailyHrs'] = $alldata->dailyHours;
        }

        //echo $alldata->adjDailyBase.',';
        $BaseDaily = $BaseDaily + $alldata->adjDailyBase;
        ///echo $alldata['DailyHours'].',';
        $BaseHours = $BaseHours + $alldata->dailyHours; //Check this for zeros

        /* Doesn't use DailyHrs which accounts for overtime
        if(empty($weekHours[$i])){
            $weekHours[$i] = $alldata->regularHours;
        } else {
            $weekHours[$i] = $weekHours[$i] + $alldata->regularHours;
        } */

        if(empty($weekHours[$i])){
            $weekHours[$i] = $alldata->dailyHours;
        } else {
            $weekHours[$i] = $weekHours[$i] + $alldata->dailyHours;
        }

        if ($columnType == 'Total') {
            /* Doesn't use DailyHrs which accounts for overtime
            if ($setterVal != 0 && $alldata->regularHours != 0) {
                $setterData[$setterID][$i] = $setterVal / $alldata->regularHours;
            } else {
                $setterData[$setterID][$i] = 0;
            } */

            if ($setterVal != 0 && $alldata->dailyHours != 0) {
                $setterData[$setterID][$i] = $setterVal / $alldata->dailyHours;
            } else {
                $setterData[$setterID][$i] = 0;
            }

        } else {
            $setterData[$setterID][$i] = $setterVal;
        }

        if ($setterVal != 0) {
            $ifsetterhas = true;

            if(empty($numberSetters[$i])){
                $numberSetters[$i] = 1;
            } else {
                $numberSetters[$i] = $numberSetters[$i] + 1;
            }
        } else {

            if(empty($numberSetters[$i])){
                $numberSetters[$i] = 0;
            } else {
                $numberSetters[$i] = $numberSetters[$i] + 0;
            }
        }

        if(empty($weekTotal[$i])){
            $weekTotal[$i] = $setterVal;
        } else {
            $weekTotal[$i] = $weekTotal[$i] + $setterVal;
        }

        $datelink = urlencode(date('m/d/Y',strtotime($header[$i])));
        $pageset.= '<td><a href="individual.php?setterNo='.$setterID.'&amp;startdate='.$datelink.'" class="setterview" id="'.$setterID.'-'.$datelink.'">'.$setterVal.'</a></td>';
    }

    $pageset.=  '</tr>'."\n";
    if ($ifsetterhas) {

        $page .= $pageset;
    }
}

/*ONE, FOUR, AND TWELVE PERIOD DATA*/
//Check if a date is selected, then format it.
if(!empty($_GET['startdate'])){
    $startDate = $startdate->format('m/d/Y');    
} else { //If not then set at null then let the readPeriod static methods provide the value
    $startDate = null;
}

//All setters except Misc Setter
foreach($setters as $setterID => $setter){
    for($period = 0; $period < 12; $period++){

        if($period < 1){ //first and only period
            //echo '<p>One Period</p>';
            $periodData['one'][$setterID][$period] = SetBase::readPeriod($setterID, $period, $periodType, $startDate);
        }

        if($period < 4){ //four periods
            //echo '<p>Four Periods</p>';
            $periodData['four'][$setterID][$period] = SetBase::readPeriod($setterID, $period, $periodType, $startDate);
        }

        if($period < 12){ //twelve periods
            //echo '<p>Twelve Periods</p>';
            $periodData['twelve'][$setterID][$period] = SetBase::readPeriod($setterID, $period, $periodType, $startDate);
        }
    }
}

//echo '<pre style="background: black; color: red;">';
//var_dump($periodData['four']);
//echo '</pre>';

foreach($periodData as $displayID => $setters){
    foreach($setters as $setterID => $periods){
        foreach($periods as $periodID => $days){
            foreach($days as $dayID => $day){ /*dayID is useless just using for logging purposes*/
                //echo '<pre style="background: black; color: green;">';
                //var_dump($setterID);
                //var_dump($periodID);
                //var_dump($dayID);
                //var_dump($day);
                //echo '</pre>';

                //Construct the baseline average
                if(isset($displayData[$displayID][$setterID]['AdjDailyBaseTotal'])){
                    if($day->getAdjDailyBase() != null){
                        $displayData[$displayID][$setterID]['AdjDailyBaseTotal'] += $day->getAdjDailyBase();
                    } else {
                        $displayData[$displayID][$setterID]['AdjDailyBaseTotal'] += 0;
                    }
                } else {
                    if($day->getAdjDailyBase() != null){
                        $displayData[$displayID][$setterID]['AdjDailyBaseTotal'] = $day->getAdjDailyBase();
                    } else {
                        $displayData[$displayID][$setterID]['AdjDailyBaseTotal'] = 0;
                    }
                }

                if(isset($displayData[$displayID][$setterID]['DailyHrsTotal'])){
                    if($day->getDailyHrs() != null){
                        $displayData[$displayID][$setterID]['DailyHrsTotal'] += $day->getDailyHrs();
                    } else {
                        $displayData[$displayID][$setterID]['DailyHrsTotal'] += 0;
                    }
                } else {
                    if($day->getDailyHrs() != null){
                        $displayData[$displayID][$setterID]['DailyHrsTotal'] = $day->getDailyHrs();
                    } else {
                        $displayData[$displayID][$setterID]['DailyHrsTotal'] = 0;
                    }
                }

                //Construct the Average Per Hour Totals (refer to line 142)
                if(isset($displayData[$displayID][$setterID]['TotalTotal'])){
                    if($day->getTotal() != null){
                        $displayData[$displayID][$setterID]['TotalTotal'] += $day->getTotal();
                    } else {
                        $displayData[$displayID][$setterID]['TotalTotal'] += 0;
                    }
                } else {
                    if($day->getTotal() != null){
                        $displayData[$displayID][$setterID]['TotalTotal'] = $day->getTotal();
                    } else {
                        $displayData[$displayID][$setterID]['TotalTotal'] = 0;
                    }
                }

                /*
                if(isset($displayData[$displayID][$setterID]['HrsTotal'])){
                    if($day->getHrs() != null){
                        $displayData[$displayID][$setterID]['HrsTotal'] += $day->getHrs();
                    } else {
                        $displayData[$displayID][$setterID]['HrsTotal'] += 0;
                    }
                } else {
                    if($day->getHrs() != null){
                        $displayData[$displayID][$setterID]['HrsTotal'] = $day->getHrs();
                    } else {
                        $displayData[$displayID][$setterID]['HrsTotal'] = 0;
                    }
                }
                */
            }

            //Setter Baseline and AveragePerHour Total
            if($displayData[$displayID][$setterID]['DailyHrsTotal'] != 0){
                $displayData[$displayID][$setterID]['BaselineTotal'] = round($displayData[$displayID][$setterID]['AdjDailyBaseTotal'] / $displayData[$displayID][$setterID]['DailyHrsTotal'], 2);

                $displayData[$displayID][$setterID]['AveragePerHourTotal'] = round($displayData[$displayID][$setterID]['TotalTotal'] / $displayData[$displayID][$setterID]['DailyHrsTotal'], 2);
            } else {
                $displayData[$displayID][$setterID]['BaselineTotal'] = 0;
                $displayData[$displayID][$setterID]['AveragePerHourTotal'] = 0;
            }

            //Now accumulate the totals for the grand total
            if(isset($displayData[$displayID]['total']['DailyHrsTotal'])){
                $displayData[$displayID]['total']['DailyHrsTotal'] += $displayData[$displayID][$setterID]['DailyHrsTotal'];
            } else {
                $displayData[$displayID]['total']['DailyHrsTotal'] = $displayData[$displayID][$setterID]['DailyHrsTotal'];
            }

            if(isset($displayData[$displayID]['total']['AdjDailyBaseTotal'])){
                $displayData[$displayID]['total']['AdjDailyBaseTotal'] += $displayData[$displayID][$setterID]['AdjDailyBaseTotal'];
            } else {
                $displayData[$displayID]['total']['AdjDailyBaseTotal'] = $displayData[$displayID][$setterID]['AdjDailyBaseTotal'];
            }

            if(isset($displayData[$displayID]['total']['TotalTotal'])){
                $displayData[$displayID]['total']['TotalTotal'] += $displayData[$displayID][$setterID]['TotalTotal'];
            } else {
                $displayData[$displayID]['total']['TotalTotal'] = $displayData[$displayID][$setterID]['TotalTotal'];
            }
        }
    }

    //echo '<pre>';
    //var_dump($setterID);
    //var_dump($displayID);
    //var_dump('AdjDailyBaseTotal '.$displayData[$displayID]['total']['AdjDailyBaseTotal']);
    //var_dump('TotalTotal '.$displayData[$displayID]['total']['TotalTotal']);
    //var_dump('DailyHrsTotal '.$displayData[$displayID]['total']['DailyHrsTotal']);
    //echo '</pre>';

    //Now calculate the grand total
    if($displayData[$displayID]['total']['DailyHrsTotal'] != 0){
        $displayData[$displayID]['total']['BaselineTotal'] = round($displayData[$displayID]['total']['AdjDailyBaseTotal'] / $displayData[$displayID]['total']['DailyHrsTotal'], 2);

        $displayData[$displayID]['total']['AveragePerHourTotal'] = round($displayData[$displayID]['total']['TotalTotal'] / $displayData[$displayID]['total']['DailyHrsTotal'], 2);
    } else {
        $displayData[$displayID]['total']['BaselineTotal'] = 0;
        $displayData[$displayID]['total']['AveragePerHourTotal'] = 0;
    }
}

//Construct the data array for the Total Baseline for the graph
foreach($setterBaselineTotal as $basePeriod => $baseData){
    if((float)$baseData['DailyHrs']){
        $setterBaseData['total'][$basePeriod] = $baseData['AdjDailyBase'] / $baseData['DailyHrs'];
    } else {
        $setterBaseData['total'][$basePeriod] = 0;
    }
}

$header =array_unique($header);

$totalLine = '';
$avgLine = '';
$weekAvgjs = "              chartData['avg'] =  ["; //Footer totals
$weekTotaljs = "              chartData['total'] =  ["; //Average per hours
$tableheader = '<th>'.$periodTitle.' of</th>';
$dataWeek = array();

//Construct the table header of the dates
foreach ($header as $period => $hdate) {
    $hdate = date('n/j/y',strtotime($hdate)); //Reformat the string dates to a different format
    $tableheader .= '<th class="table-date">'.$hdate.'</th>'; //Add the thead items into the string
    $dataWeek[$period] = $hdate; //X-axis chart labeling
}

//weekTotal displays the grand totals of something per period, non-rounded values

//Construct the totals footer
foreach ($weekTotal as $period => $thisTotal) {
    //Average per hour
    if ($columnType == 'Total') {
        if($weekHours[$period]){

            $weekTotaljs .= '['.$period.','.round($thisTotal / $weekHours[$period], 2).'],';

        } else {
            $weekTotaljs .= '['.$period.', 0],';
        }
        
        $totalLine .= '<th class="table-total">'.number_format($thisTotal, 0).'</th>';
    } else { //Any other column type
        $weekTotaljs .= '[' . $period . ',' . round($thisTotal, 2) . '],';
        $totalLine.= '<th class="table-total">'.number_format($thisTotal, 2).'</th>';
    }


    if($numberSetters[$period]){
        $weekAvgjs.= '['.$period.','.round($thisTotal / $numberSetters[$period], 2).'],';
    } else {
        $weekAvgjs.= '['.$period.', 0],';
    }
    
    //This is comment out on the site
    if($numberSetters[$period]){
        $avgLine.= '<th>'.number_format($thisTotal / $numberSetters[$period], 2).'</th>';
    } else {
        $avgLine.= '<th>0</th>';
    }
}

$page = '<table class="table view-1-table">'."\n".'<tr>'.$tableheader.'</tr>'."\n".$page."\n".'<tr class="chartLoad" id="total"><th class="settername">Total</th>'.$totalLine.'</tr>'."\n".'<!--<tr class="chartLoad" id="avg"><th class="settername">Average</th>'.$avgLine.'</tr>-->'."\n".'</table>'; ?>

<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-xs-1">
                <button class="btn btn-primary pull-left week-plus-top"><span class="glyphicon glyphicon-menu-left"></span></button>
            </div>
            <div class="col-xs-10">
                <form class="form-inline  date-select">
                    <input type="hidden" name="setterNo" id="currentSetterNo" value="<?php echo $_GET['setterNo'];?>" />
                    <div class="form-group">
                        
                        <?php if(isset($_GET['startdate'])){
                            $startDateValue = $_GET['startdate'];
                        } else {
                            $startDateValue = '';
                        } ?>

                        <label for="startdate">Start Week:</label>
                        <input type="text" name="startdate"  class="form-control small-field input-sm" id="startdate" value="<?php echo urldecode($startDateValue); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="column">Period:</label>
                        <select name="period" id="period"  class="form-control input-sm">
                            <?php
                            foreach ($periodChoice as $columnc){
                                if ($_GET['period'] == $columnc) {
                                    echo '<option value="'.$columnc.'" selected="selected">'.$columnc.'</option>'."\n";
                                } else {
                                    echo '<option value="'.$columnc.'">'.$columnc.'</option>'."\n";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="column">Number:</label>
                        <input type="text" name="number"  class="form-control ex-small-field input-sm" id="number" value="<?php echo urldecode($noPeriods); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="column">Data:</label>
                        <select name="column" id="column"  class="form-control input-sm">
                            <?php
                            foreach ($columnChoice as $columnp){
                                if ($columnType == $columnp) {
                                    echo '<option value="'.$columnp.'" selected="selected">'.$columnp.'</option>'."\n";
                                } else {
                                    echo '<option value="'.$columnp.'">'.$columnp.'</option>'."\n";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-default btn-sm">View</button>
                </form>
            </div>
            <div class="col-xs-1">      
                <button class="btn btn-primary pull-right week-minus-top"><span class="glyphicon glyphicon-menu-right"></span></button>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">

            </div>
        </div>

        <?php if(isset($notice)){
            echo $notice;    
        } ?>

        <div class="scroll">
            <div class="scroll-inner">

            <?php echo $page;?>

            </div>
        </div>
        <div class="row">
            <div class="col-xs-1">
                <button class="btn btn-primary pull-left week-plus"><span class="glyphicon glyphicon-menu-left"></span></button><a  name="chart"></a>
            </div>
            <div class="col-xs-10">
                <h4 class="chart-title">Select a line above</h4>
            </div>
            <div class="col-xs-1">
                <button class="btn btn-primary pull-right week-minus"><span class="glyphicon glyphicon-menu-right"></span></button>
            </div>
        </div>
        <div class="chart-container">
            <div id="chart1" class="achart"></div>
        </div>

        <div class="row" id="display rows">
            <div class="col-xs-4 display-table" id="one-display-table">
                <p>1 Period(s)</p>
                <table></table>
            </div>
            <div class="col-xs-4 display-table" id="four-display-table">
                <p>4 Period(s)</p>
                <table></table>
            </div>
            <div class="col-xs-4 display-table" id="twelve-display-table">
                <p>12 Period(s)</p>
                <table></table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="baseModal" tabindex="-1" role="dialog" aria-labelledby="baseModaltitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="baseModaltitle">Set Baseline for <span class="baselineName"></span></h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="get" id="baselineForm">
                    <input type="hidden" name="startdate" value="<?php echo $_GET['startdate'];?>" />
                    <input type="hidden" name="period" value="<?php echo $_GET['period'];?>" />
                    <input type="hidden" name="column" value="<?php echo $columnType;?>" />
                    <input type="hidden" name="number" value="<?php echo $noPeriods;?>" />
                    <input type="hidden" name="setterNo" id="setterNo" value="" />
                    <input type="hidden" name="view" value="1" />
                    <input type="hidden" name="setbase" value="true" />
                    <div class="form-group">
                        <label for="baseline_date">Start Date</label>
                        <input type="text" class="form-control" id="baseline_date" name="baseline_date" placeholder="Enter Date" value="<?php echo date('m/d/Y');?>">
                    </div>
                    <div class="form-group">
                        <label for="baseline_value">Baseline</label>
                        <input type="text" class="form-control" id="baseline_value" name="baseline_value" placeholder="Enter Baseline Value">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="baseSave">Save changes</button>
            </div>
        </div>
    </div>
</div>

<?php

if(!isset($_GET['period'])){
    $_GET['period'] = '';
} ?>


<?php require_once('inc/footer.php'); ?>

<script>
//Need to keep this after footer include
(function($, window, document){
    $(function(){
        var setter = "";
        var ctitle = "";
        var baselineID ="";
        var baselineName = "";

        $(".week-minus-top").click(function(){
            window.location.href = "index.php?startdate=<?=urlencode($prevdate->format('m/d/Y')); ?>&period=<?=$_GET['period']; ?>&column=<?=$columnType; ?>&number=<?=$noPeriods; ?>&setterNo=" + setter;
        });

        $(".week-plus-top").click(function(){
            window.location.href = "index.php?startdate=<?=urlencode($nextdate->format('m/d/Y')); ?>&period=<?=$_GET['period']; ?>&column=<?=$columnType; ?>&number=<?=$noPeriods; ?>&setterNo=" + setter;
        });

        $(".week-minus").click(function(){
            window.location.href = "index.php?startdate=<?=urlencode($prevdate->format('m/d/Y')); ?>&period=<?=$_GET['period']; ?>&column=<?=$columnType; ?>&number=<?=$noPeriods; ?>&setterNo=" + setter + "&#chart";
        });

        $(".week-plus").click(function(){
            window.location.href = "index.php?startdate=<?=urlencode($nextdate->format('m/d/Y')); ?>&period=<?=$_GET['period']; ?>&column=<?=$columnType; ?>&number=<?=$noPeriods; ?>&setterNo=" + setter + "&#chart";
        });

        $("#baseSave").click(function(){
            //$("#setterNo").val(baselineID);
            $("#baselineForm").submit();
        });

        window.setTimeout(function() { $(".alert").slideUp(); }, 3500);

        $(".baseSet").click(function(){
            baselineID =  $(this).parent().parent().attr("id");
            baselineName =  $(this).parent().text();
            //alert(baselineID);
            //alert(baselineName);
            $("#setterNo").val(baselineID);
            $(".baselineName").text(baselineName);
            $("#baseModal").modal({show:true});
        });
        

        $( "#startdate" ).datepicker({maxDate: new Date, minDate: new Date(2000, 1, 1) });
        $( "#baseline_date" ).datepicker();

        var chartData = [];
        var baseData = [];
        var oneData = [];
        var fourData = [];
        var twelveData = [];
        var dataTicks = [];
        var dataPoint = [];

        <?php foreach($setterData as $setter => $data): ?>
            chartData['<?=$setter; ?>'] = [
            <?php foreach($setterData[$setter] as $period => $point): ?>
            ['<?=$period; ?>', '<?=$point; ?>'],
            <?php endforeach; ?>
            ];
        <?php endforeach; 

        echo $weekTotaljs.'];'; //This adds to the chartData JS array
        echo $weekAvgjs.'];'; //This adds to the chartData JS array ?>

        console.log('Chart Data');
        console.log(chartData);

        <?php //Baseline data
        foreach($setterBaseData as $setter => $data): ?>
            baseData['<?=$setter; ?>'] = [
            <?php foreach($setterBaseData[$setter] as $period => $point): ?>
                ['<?=$period; ?>', '<?=$point; ?>'],
            <?php endforeach; ?>
            ];
        <?php endforeach; ?>

        console.log('Baseline Chart Data');
        console.log(baseData);

        <?php //Three Displays
        foreach($displayData as $displayID => $setters):
            foreach($setters as $setterID => $data): ?>
                <?=$displayID; ?>Data['<?=$setterID; ?>'] = [
                    ['BaselineTotal', '<?=$data['BaselineTotal']; ?>'],
                    ['AveragePerHourTotal', '<?=$data['AveragePerHourTotal']; ?>']
                ];
            <?php endforeach;
        endforeach; ?>

        console.log('One Data');
        console.log(oneData);

        console.log('Four Data');
        console.log(fourData);

        console.log('Twelve Data');
        console.log(twelveData);

        //X-Axis Labeling - Though unsure the difference between dataTicks and dataPoints
        dataTicks[1] = [
        <?php foreach($dataWeek as $key => $value): ?>
            ['<?=$key; ?>', '<?=$value; ?>'],
        <?php endforeach; ?>
        ];

        console.log('Data Ticks');
        console.log(dataTicks);

        <?php foreach($dataWeek as $key => $value): ?>
            dataPoint['<?=$key-1; ?>'] = '<?=$value; ?>';
        <?php endforeach; ?>

        console.log('Data Points');
        console.log(dataPoint);

        $(".chartLoad").click(function(){
            setter = $(this).attr("id");
            ctitle = $(this).children(".settername").text();

            //Load the three period displays
            $('#one-display-table table').html(loadDisplay(setter, oneData));
            $('#four-display-table table').html(loadDisplay(setter, fourData));
            $('#twelve-display-table table').html(loadDisplay(setter, twelveData));

            //Load the primary line graph
            $(".chartLoad").css("backgroundColor","");
            $(this).css("backgroundColor","#f2eee1");
            $(".chart-title").text(ctitle + " - Hourly Averages");
            $("#currentSetterNo").val(setter);
            $.plot($("#chart1"), [{
                data: chartData[setter],
                <?php if($columnType == 'Total'): ?>
                    label: ' Average Per Hour',
                <?php else: ?>
                    label: ' <?=$columnType; ?> Per <?=$periodTitle; ?>',
                <?php endif; ?>
            }
            <?php if($columnType == 'Total'): ?>
            ,{
                data: baseData[setter],
                label: ' Baseline'
            }
            <?php endif; ?>
            ],{
                series: {
                    lines: {
                        show: true,
                        lineWidth: 2,
                        fill: true,
                        fillColor:{
                            colors: [{
                                opacity: 0.05
                            }, {
                                opacity: 0.01
                            }]
                        }
                    },
                    points: {
                        show: true
                    },
                    shadowSize: 2
                },
                grid:{
                    hoverable: true,
                    clickable: true,
                    tickColor: '#eee',
                    borderWidth: 0
                },
                colors: ["#d12610", "#37b7f3", "#52e136"],
                xaxis:{
                    ticks: dataTicks[1]
                }
            });
        });

        <?php if(isset($_GET['setterNo'])): ?>
            <?php if($_GET['setterNo'] == 'total'): ?>
                $('#total').trigger('click');
            <?php elseif($_GET['setterNo'] == 'avg'): ?>
                $('#avg').trigger('click');
            <?php else: ?>
                $('#<?=$_GET['setterNo']; ?>').trigger('click');
            <?php endif; ?>
        <?php else: ?>
            $('#total').trigger('click');
        <?php endif; ?>

        $("#chart1").bind("plotclick", function (event, pos, item) {
            if (item) {
                if (item.series.label == "&nbsp;baseline"){

                    $("#baseline_date").val(dataPoint[item.dataIndex]);
                    $("#setterNo").val(setter);
                    $(".baselineName").text(ctitle);
                    $("#baseModal").modal({show:true});
                    //alert(" - click point " + dataPoint[item.dataIndex] + " in " + item.series.label);
                }
                plot.highlight(item.series, item.datapoint);
            }
        });

        function loadDisplay(setterID, data){
            var baseline;
            var aph;
            var baselineP;
            var aphP;

            console.log(setterID);

            baseline = data[setterID][0][1];
            aph = data[setterID][1][1];

            baselineP = '<p>Baseline Avg: $' + baseline + '</p>';
            aphP = '<p>Production Avg: $' + aph + '</p>';

            return baselineP + aphP;

        }

        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 15,
                border: '1px solid #333',
                padding: '4px',
                color: '#fff',
                'border-radius': '3px',
                'background-color': '#333',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        var previousPoint = null;
        
        $("#chart1").bind("plothover", function (event, pos, item) {
            $("#x").text(pos.x.toFixed(2));
            $("#y").text(pos.y.toFixed(2));

            if (item) {
                if (previousPoint != item.dataIndex) {
                    previousPoint = item.dataIndex;
                    $("#tooltip").remove();
                    var x = item.datapoint[0].toFixed(2),
                        y = item.datapoint[1].toFixed(2);
                    showTooltip(item.pageX, item.pageY, item.series.label + " : " + y);
                }
            } else {
                $("#tooltip").remove();
                previousPoint = null;
            }
        });
    });
}(window.jQuery, window, document));
</script>