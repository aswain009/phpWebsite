<?php

//VIEW SETTINGS

//How many weeks/months to display at a time DEFAULT
$main_weeks = 12;
date_default_timezone_set('America/New_York');


//No cache pages
header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.

//set start page to first view if not selected
//DEPRECATED//
/*
if(!isset($_GET['view'])) {
    $_GET['view'] = 1;
}
*/
//build menu active class
//DEPRECATED//
/*
$active1 = '';
$active2 = '';
$active3 = '';
$active4 = '';
${'active'.$_GET['view']} = ' class="active"';
*/

//DATABASE INITIALIZATION
$dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
$opt = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => FALSE,
);
$pdo = new PDO($dsn,DB_USER,DB_PASSWORD, $opt);

if (!$pdo){
    echo 'ERROR: Cannot connect to database.';
    exit();
}

//start output buffering and get the required view

//DEPRECATED//
/*
ob_start( );
require ('inc/views/view'.$_GET['view'].'.php');
$output = ob_get_clean();
*/