<?php

$setters = get_setters();

if (!isset($_GET['column'])) {
    $_GET['column'] = 'Total';
}

if (isset($_GET['number'])) {
    $main_weeks =  $_GET['number'];
}

if (!isset($_GET['number'])) {
    $_GET['number'] = $main_weeks;
}

//set period titles
if (isset($_GET['period']) && $_GET['period'] == "Monthly") {
    $periodTitle = 'Month';
} else {
    $periodTitle = 'Week';
}

if (isset($_GET['setbase']) && $_GET['setbase'] == 'true') {
    $notice = setBase($_GET['setterNo'],$_GET['baseline_date'],$_GET['baseline_value']);
}

$columnChoice = array ('Total','Hrs','OThrs','Qty','Amt','Brk','Bamt','AQ','AA');
$periodChoice = array ('Weekly', 'Monthly');

if ($_GET['startdate']) {
    if ($_GET['period'] == "Monthly") {
        $startdate = urldecode($_GET['startdate']);
        $startdate = strtotime($startdate);
        $startdate = strtotime('first day of next month', $startdate);
        $startdate = date('m/d/Y', $startdate);
        $prevdate = urlencode(date('m/d/y',strtotime('-1 month',strtotime($_GET['startdate']))));
        $nextdate = urlencode(date('m/d/y',strtotime('+1 month',strtotime($_GET['startdate']))));

    } else {
        $startdate = urldecode($_GET['startdate']);
        $startdate = strtotime($startdate);
        $startdate = strtotime('monday next week', $startdate);
        $startdate = date('m/d/Y', $startdate);
        $prevdate = urlencode(date('m/d/y',strtotime('-7 day',strtotime($_GET['startdate']))));
        $nextdate = urlencode(date('m/d/y',strtotime('+7 day',strtotime($_GET['startdate']))));
    }

} else {
    if ($_GET['period'] == "Monthly") {
        $startdate = time();
        $startdate = strtotime('first day of this month', $startdate);
        $startdate = date('m/d/Y', $startdate);
        $prevdate = urlencode(date('m/d/y',strtotime('-2 months',strtotime( $startdate))));
        $nextdate = urlencode(date('m/d/y',strtotime( $startdate)));
    } else {
        $startdate = time();
        $startdate = strtotime('monday this week', $startdate);
        $startdate = date('m/d/Y', $startdate);
        $prevdate = urlencode(date('m/d/y',strtotime('-14 day',strtotime( $startdate))));
        $nextdate = urlencode(date('m/d/y',strtotime( $startdate)));
    }
}

$page = '';
$range = array();
$weekTotal = array();
$weekHours = array();
$header = array();
$setterData = array();
$numberSetters = array();

foreach($setters as $key => $setter) {

    $pageset = '';
    $ifsetterhas = '';
    $pageset.=  '<tr class="chartLoad" id="'.$key.'"><td class="settername">'.$setter.' <span class="glyphicon glyphicon-wrench baseSet"></span></td>';
    $range['firstday'] = $startdate;
    
    $BaseDaily = 0;
    $BaseHours = 0;

    for ($i=1; $i <= $main_weeks; $i++) {

        $setterData[$key][$i] = $setterData;
        if (isset($_GET['period']) && $_GET['period'] == "Monthly") {
            $range = get_month_before($range['firstday']);
        } else {
            $range = get_week_before($range['firstday']);
        }

        $header[$i] = $range['firstday'];

        $alldata = get_setter_data($range['firstday'], $range['lastday'], $key, $_GET['column']);

        $setterVal = $alldata['data'];


        //get baseline for setter
        //$setterBase = get_setter_baseline($range['firstday'],$range['lastday'],$key);
        //$setterBaseData[$key][$i] = $setterBase;
        //echo '<pre>';
        //var_dump($range);
        //var_dump($alldata);
        //echo '</pre>';

        ## NEW get baseline for setter
        $setterBaseDaily[$key][$i] = $alldata['AdjDailyBase'];
        //echo $alldata['AdjDailyBase'].',';
        $BaseDaily = $BaseDaily + $alldata['AdjDailyBase'];
        ///echo $alldata['DailyHours'].',';
        $setterBaseDailyHours[$key][$i] = $alldata['DailyHrs'];
        $BaseHours = $BaseHours + $alldata['DailyHrs']; //Check this for zeros

        //echo '<p>'.$setterVal.'/'.$alldata['Hrs'].' = '.$setterVal/$alldata['Hrs'].'</p>';
        if(empty($weekHours[$i])){
            $weekHours[$i] = $alldata['Hrs'];
        } else {
            $weekHours[$i] = $weekHours[$i] + $alldata['Hrs'];
        }

        if ($_GET['column'] == 'Total') {
            if ($setterVal != 0 && $alldata['Hrs'] != 0) {
                $setterData[$key][$i] = $setterVal / $alldata['Hrs'];
            } else {
                $setterData[$key][$i] = 0;
            }
        } else {
            $setterData[$key][$i] = $setterVal;
        }

        if ($setterVal != 0) {
            $ifsetterhas = true;

            if(empty($numberSetters[$i])){
                $numberSetters[$i] = 1;
            } else {
                $numberSetters[$i] = $numberSetters[$i] + 1;
            }
            
        } else {

            if(empty($numberSetters[$i])){
                $numberSetters[$i] = 0;
            } else {
                $numberSetters[$i] = $numberSetters[$i] + 0;
            }
        }

        if(empty($weekTotal[$i])){
            $weekTotal[$i] = $setterVal;
        } else {
            $weekTotal[$i] = $weekTotal[$i] + $setterVal;
        }

        $datelink = urlencode(date('m/d/Y',strtotime($header[$i])));
        $pageset.= '<td><a href="index.php?view=2&amp;setterNo='.$key.'&amp;startdate='.$datelink.'" class="setterview" id="'.$key.'-'.$datelink.'">'.$setterVal.'</a></td>';
    }

    ## NEW get baseline for setter as above
    //$setterBaseData[$key]
    if($BaseHours):
        echo $setter.'<br/>';
        echo "baseDaily:".$BaseDaily." BaseHours:".$BaseHours.' = '.($BaseDaily / $BaseHours).'<br/>';
    endif;
    
    foreach ($setterBaseDaily[$key] as $k3=> $v3) {
        if($BaseHours){ //dividing by zero    
            $setterBaseData[$key][$k3] = $BaseDaily / $BaseHours;
        } else {

            $setterBaseData[$key][$k3] = 0;
        }
        
    }

    $pageset.=  '</tr>'."\n";
    if ($ifsetterhas) {

        $page .= $pageset;
    }

}

$header =array_unique($header);

$totalLine = '';
$avgLine = '';
$weekAvgjs = "              chartData['avg'] =  [";
$weekTotaljs = "              chartData['total'] =  [";
$tableheader = '<th>'.$periodTitle.' of</th>';
$dataWeek = array();

foreach ($header as $k=>$hdate) {
    $hdate = date('n/j/y',strtotime($hdate));
    $tableheader.= '<th>'.$hdate.'</th>';
    $dataWeek[$k] = $hdate;
}

//print_r($weekHours);
foreach ($weekTotal as $k=>$thisTotal) {
    if ($_GET['column'] == 'Total') {
        if($weekHours[$k]){
            $weekTotaljs .= '['.$k.','.round($thisTotal/$weekHours[$k],2).'],';    
        } else {
            $weekTotaljs .= '['.$k.', 0],';
        }
        
        
        $totalLine .= '<th>'.number_format($thisTotal,0).'</th>';
    } else {
        $weekTotaljs .= '[' . $k . ',' . round($thisTotal, 2) . '],';
        
        $totalLine.= '<th>'.number_format($thisTotal,2).'</th>';
    }

    if($numberSetters[$k]){
        $weekAvgjs.= '['.$k.','.round($thisTotal / $numberSetters[$k],2).'],';
    } else {
        $weekAvgjs.= '['.$k.', 0],';
    }
    
    if($numberSetters[$k]){
        $avgLine.= '<th>'.number_format($thisTotal / $numberSetters[$k],2).'</th>';
    } else {
        $avgLine.= '<th>0</th>';
    }

    
}
$page = '<table class="table view-1-table">'."\n".'<tr>'.$tableheader.'</tr>'."\n".$page."\n".'<tr class="chartLoad" id="total"><th class="settername">Total</th>'.$totalLine.'</tr>'."\n".'<!--<tr class="chartLoad" id="avg"><th class="settername">Average</th>'.$avgLine.'</tr>-->'."\n".'</table>';

//$weekMinusTop = 'index.php?view=1&startdate='.$prevdate.'&period='.$_GET['period'].'&column='.$_GET['column'].'&number='.$_GET['number'].'&setterNo='.$setter;


?>

<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-xs-1">
                <button class="btn btn-primary pull-left week-plus-top"><span class="glyphicon glyphicon-menu-left"></span></button>
            </div>
            <div class="col-xs-10">
                <form class="form-inline  date-select">
                    <input type="hidden" name="setterNo" id="currentSetterNo" value="<?php echo $_GET['setterNo'];?>" />
                    <div class="form-group">
                        
                        <?php if(isset($_GET['startdate'])){
                            $startDateValue = $_GET['startdate'];
                        } else {
                            $startDateValue = '';
                        } ?>

                        <label for="startdate">Start Week:</label>
                        <input type="text" name="startdate"  class="form-control small-field input-sm" id="startdate" value="<?php echo urldecode($startDateValue); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="column">Period:</label>
                        <select name="period" id="period"  class="form-control input-sm">
                            <?php
                            foreach ($periodChoice as $columnc){
                                if ($_GET['period'] == $columnc) {
                                    echo '<option value="'.$columnc.'" selected="selected">'.$columnc.'</option>'."\n";
                                } else {
                                    echo '<option value="'.$columnc.'">'.$columnc.'</option>'."\n";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="column">Number:</label>
                        <input type="text" name="number"  class="form-control ex-small-field input-sm" id="number" value="<?php echo urldecode($_GET['number']); ?>" />
                    </div>
                    <div class="form-group">
                        <label for="column">Data:</label>
                        <select name="column" id="column"  class="form-control input-sm">
                            <?php
                            foreach ($columnChoice as $columnp){
                                if ($_GET['column'] == $columnp) {
                                    echo '<option value="'.$columnp.'" selected="selected">'.$columnp.'</option>'."\n";
                                } else {
                                    echo '<option value="'.$columnp.'">'.$columnp.'</option>'."\n";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-default btn-sm">View</button>
                </form>
            </div>
            <div class="col-xs-1">      
                <button class="btn btn-primary pull-right week-minus-top"><span class="glyphicon glyphicon-menu-right"></span></button>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">

            </div>
        </div>

        <?php if(isset($notice)){
            echo $notice;    
        } ?>

        <div class="scroll">
            <div class="scroll-inner">

            <?php echo $page;?>

            </div>
        </div>
        <div class="row">
            <div class="col-xs-1">
                <button class="btn btn-primary pull-left week-plus"><span class="glyphicon glyphicon-menu-left"></span></button><a  name="chart"></a>
            </div>
            <div class="col-xs-10">
                <h4 class="chart-title">Select a line above</h4>
            </div>
            <div class="col-xs-1">
                <button class="btn btn-primary pull-right week-minus"><span class="glyphicon glyphicon-menu-right"></span></button>
            </div>
        </div>
        <div class="chart-container">
            <div id="chart1" class="achart"></div>
        </div>

        <div class="row">
            <div class="col-xs-4">
                <p>1 Period(s)</p>
            </div>
            <div class="col-xs-4">
                <p>4 Period(s)</p>
            </div>
            <div class="col-xs-4">
                <p>12 Period(s)</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="baseModal" tabindex="-1" role="dialog" aria-labelledby="baseModaltitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="baseModaltitle">Set Baseline for <span class="baselineName"></span></h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="get" id="baselineForm">
                    <input type="hidden" name="startdate" value="<?php echo $_GET['startdate'];?>" />
                    <input type="hidden" name="period" value="<?php echo $_GET['period'];?>" />
                    <input type="hidden" name="column" value="<?php echo $_GET['column'];?>" />
                    <input type="hidden" name="number" value="<?php echo $_GET['number'];?>" />
                    <input type="hidden" name="setterNo" id="setterNo" value="" />
                    <input type="hidden" name="view" value="1" />
                    <input type="hidden" name="setbase" value="true" />
                    <div class="form-group">
                        <label for="baseline_date">Start Date</label>
                        <input type="text" class="form-control" id="baseline_date" name="baseline_date" placeholder="Enter Date" value="<?php echo date('m/d/Y');?>">
                    </div>
                    <div class="form-group">
                        <label for="baseline_value">Baseline</label>
                        <input type="text" class="form-control" id="baseline_value" name="baseline_value" placeholder="Enter Baseline Value">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="baseSave">Save changes</button>
            </div>
        </div>
    </div>
</div>

<?php

if(!isset($_GET['period'])){
    $_GET['period'] = '';
}

//echo '<pre style="background: black; color: cyan;">';
//var_dump($setterBaseData);
//echo '</pre>';

$js = '';
/*
$js = '

    (function($, window, document) {
        $(function() {
            var setter = "";
            var ctitle = "";
            var baselineID ="";
            var baselineName = "";
            $(".week-minus-top").click(function(){
                window.location.href = "index.php?view=1&startdate='.$prevdate.'&period='.$_GET['period'].'&column='.$_GET['column'].'&number='.$_GET['number'].'&setterNo=" + setter;
            });
            $(".week-plus-top").click(function(){
                window.location.href = "index.php?view=1&startdate='.$nextdate.'&period='.$_GET['period'].'&column='.$_GET['column'].'&number='.$_GET['number'].'&setterNo=" + setter;
            });
            $(".week-minus").click(function(){
                window.location.href = "index.php?view=1&startdate='.$prevdate.'&period='.$_GET['period'].'&column='.$_GET['column'].'&number='.$_GET['number'].'&setterNo=" + setter + "&#chart";
            });
            $(".week-plus").click(function(){
                window.location.href = "index.php?view=1&startdate='.$nextdate.'&period='.$_GET['period'].'&column='.$_GET['column'].'&number='.$_GET['number'].'&setterNo=" + setter + "&#chart";
            });

console.log(setter);
            $("#baseSave").click(function(){
                //$("#setterNo").val(baselineID);
                $("#baselineForm").submit();
            });

            window.setTimeout(function() { $(".alert").slideUp(); }, 3500);
            
            $(".baseSet").click(function(){
              baselineID =  $(this).parent().parent().attr("id");
              baselineName =  $(this).parent().text();
              //alert(baselineID);
              //alert(baselineName);
              $("#setterNo").val(baselineID);
              $(".baselineName").text(baselineName);
              $("#baseModal").modal({show:true});
            });
            

            $( "#startdate" ).datepicker({ maxDate: new Date, minDate: new Date(2000, 1, 1) });

            $( "#baseline_date" ).datepicker();



            var chartData = [];
            var baseData = [];
            var dataTicks = [];
            var dataPoint = [];

';

            //This will make the data variables
            foreach($setterData as $setter=>$data){
                $js.= '              chartData['.$setter.'] =  [';
                foreach($setterData[$setter] as $week=>$point){
                    $js.= '['.$week.','.$point.'],';

                }
                $js.= '];'."\n";
            }
            $js.= $weekTotaljs.'];'."\n";
            $js.= $weekAvgjs.'];'."\n";

            foreach($setterBaseData as $setter=>$data){
                $js.= '              baseData['.$setter.'] =  [';
                foreach($setterBaseData[$setter] as $week=>$point){
                    if (!$point) {
                        $point = 0;
                    }
                    $js.= '['.$week.','.$point.'],';

                }
                $js.= '];'."\n";
            }

            $js.= '             dataTicks[1] =  [';
            $js2 = '';
            foreach ($dataWeek as $k=>$v) {
                $js2.= 'dataPoint['.($k-1).'] = "'.$v.'"'."\n";
                $js.= '['.$k.',"'.$v.'"],';
            }
            $js.= '];'."\n";
            $js.=$js2;
$js.= '


            console.log("Real Results");
            console.log(chartData);

            $(".chartLoad").click(function(){

                setter = $(this).attr("id");
                ctitle = $(this).children(".settername").text();
                $(".chartLoad").css("backgroundColor","");
                $(this).css("backgroundColor","#f2eee1");
                $(".chart-title").text(ctitle + " - Hourly Averages");
                $("#currentSetterNo").val(setter);
                $.plot($("#chart1"), [{
                    data: chartData[setter],
                    ';
                    if ($_GET['column'] == 'Total') {
                        $js .= 'label: "&nbsp;Average Per Hour"';
                    } else {
                        $js .= 'label: "&nbsp;'.$_GET['column'].' Per '.$periodTitle.'"';
                    }
                    $js .= '



                }
                ';
                if ($_GET['column'] == 'Total') {
$js .= '
                ,{
                    data: baseData[setter],
                    label: "&nbsp;baseline"
                }
                ';
                }
$js.='
                ],

                {
                series: {
                    lines: {
                        show: true,
                        lineWidth: 2,
                        fill: true,
                        fillColor: {
                            colors: [{
                                    opacity: 0.05
                                }, {
                                    opacity: 0.01
                                }
                            ]
                        }
                    },
                    points: {
                        show: true
                    },
                    shadowSize: 2
                },
                grid: {
                    hoverable: true,
                    clickable: true,
                    tickColor: "#eee",
                    borderWidth: 0
                },
                colors: ["#d12610", "#37b7f3", "#52e136"],
                xaxis: {
                    ticks: dataTicks[1]

                }

                }

                 );
            });

';
 if (isset($_GET['setterNo'])) {

     if ($_GET['setterNo'] == 'total') {
         $js .= '

            $( "#total").trigger( "click" );

        ';
     }elseif ($_GET['setterNo'] == 'avg'){
         $js .= '

            $( "#avg").trigger( "click" );

        ';
     } else {

         $js .= '

            $( "#" + ' . $_GET['setterNo'] . '  ).trigger( "click" );

        ';
     }

 } else {
     $js .= '

            $( "#total").trigger( "click" );

        ';
 }
$js.='

                $("#chart1").bind("plotclick", function (event, pos, item) {
                    if (item) {
                        if (item.series.label == "&nbsp;baseline"){

                            $("#baseline_date").val(dataPoint[item.dataIndex]);
                            $("#setterNo").val(setter);
                            $(".baselineName").text(ctitle);
                            $("#baseModal").modal({show:true});
                            //alert(" - click point " + dataPoint[item.dataIndex] + " in " + item.series.label);
                        }
                        plot.highlight(item.series, item.datapoint);
                    }
                });

                function showTooltip(x, y, contents) {
                    $(\'<div id="tooltip">\' + contents + \'</div>\').css({
                            position: \'absolute\',
                            display: \'none\',
                            top: y + 5,
                            left: x + 15,
                            border: \'1px solid #333\',
                            padding: \'4px\',
                            color: \'#fff\',
                            \'border-radius\': \'3px\',
                            \'background-color\': \'#333\',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                }
                var previousPoint = null;
                $("#chart1").bind("plothover", function (event, pos, item) {
                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));

                    if (item) {
                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;
                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);
                            showTooltip(item.pageX, item.pageY, item.series.label + " : " + y);
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });

        });
        // Functions go here!




    }(window.jQuery, window, document));

';
*/ ?>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/flot/jquery.flot.min.js"></script>
<script src="js/flot/jquery.flot.resize.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!--<script src="js/bootstrap.min.js"></script>-->
<!-- Include custom scripting -->
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>

<script>
(function($, window, document){
    $(function(){
        var setter = "";
        var ctitle = "";
        var baselineID ="";
        var baselineName = "";

        $(".week-minus-top").click(function(){
            window.location.href = "index.php?view=1&startdate=<?=$prevdate; ?>&period=<?=$_GET['period']; ?>&column=<?=$_GET['column']; ?>&number=<?=$_GET['number']; ?>&setterNo=" + setter;
        });

        $(".week-plus-top").click(function(){
            window.location.href = "index.php?view=1&startdate=<?=$nextdate; ?>&period=<?=$_GET['period']; ?>&column=<?=$_GET['column']; ?>&number=<?=$_GET['number']; ?>&setterNo=" + setter;
        });

        $(".week-minus").click(function(){
            window.location.href = "index.php?view=1&startdate=<?=$prevdate; ?>&period=<?=$_GET['period']; ?>&column=<?=$_GET['column']; ?>&number=<?=$_GET['number']; ?>&setterNo=" + setter + "&#chart";
        });

        $(".week-plus").click(function(){
            window.location.href = "index.php?view=1&startdate=<?=$nextdate; ?>&period=<?=$_GET['period']; ?>&column=<?=$_GET['column']; ?>&number=<?=$_GET['number']; ?>&setterNo=" + setter + "&#chart";
        });

        $("#baseSave").click(function(){
            //$("#setterNo").val(baselineID);
            $("#baselineForm").submit();
        });

        window.setTimeout(function() { $(".alert").slideUp(); }, 3500);

        $(".baseSet").click(function(){
            baselineID =  $(this).parent().parent().attr("id");
            baselineName =  $(this).parent().text();
            //alert(baselineID);
            //alert(baselineName);
            $("#setterNo").val(baselineID);
            $(".baselineName").text(baselineName);
            $("#baseModal").modal({show:true});
        });
        

        $( "#startdate" ).datepicker({ maxDate: new Date, minDate: new Date(2000, 1, 1) });

        $( "#baseline_date" ).datepicker();

        var chartData = [];
        var baseData = [];
        var dataTicks = [];
        var dataPoint = [];

        <?php foreach($setterData as $setter => $data): ?>
            chartData['<?=$setter; ?>'] = [
            <?php foreach($setterData[$setter] as $week => $point): ?>
            ['<?=$week; ?>', '<?=$point; ?>'],
            <?php endforeach; ?>
            ];
        <?php endforeach; 

        echo $weekTotaljs.'];'; //This adds to the chartData JS array
        echo $weekAvgjs.'];'; //This adds to the chartData JS array ?>

        <?php foreach($setterBaseData as $setter => $data): ?>
            baseData['<?=$setter; ?>'] = [
            <?php foreach($setterBaseData[$setter] as $week => $point): ?>
                ['<?=$week; ?>', '<?=$point; ?>'],
            <?php endforeach; ?>
            ];
        <?php endforeach; ?>

        dataTicks[1] = [
        <?php foreach($dataWeek as $key => $value): ?>
            ['<?=$key; ?>', '<?=$value; ?>'],
        <?php endforeach; ?>
        ];

        <?php foreach($dataWeek as $key => $value): ?>
            dataPoint['<?=$key-1; ?>'] = '<?=$value; ?>';
        <?php endforeach; ?>

        console.log(baseData);

        $(".chartLoad").click(function(){
            setter = $(this).attr("id");
            ctitle = $(this).children(".settername").text();
            $(".chartLoad").css("backgroundColor","");
            $(this).css("backgroundColor","#f2eee1");
            $(".chart-title").text(ctitle + " - Hourly Averages");
            $("#currentSetterNo").val(setter);
            $.plot($("#chart1"), [{
                data: chartData[setter],
                <?php if($_GET['column'] == 'Total'): ?>
                    label: ' Average Per Hour',
                <?php else: ?>
                    label: ' <?=$_GET['column']; ?> Per <?=$periodTitle; ?>',
                <?php endif; ?>
            }
            <?php if($_GET['column'] == 'Total'): ?>
            ,{
                data: baseData[setter],
                label: ' Baseline'
            }
            <?php endif; ?>
            ],{
                series: {
                    lines: {
                        show: true,
                        lineWidth: 2,
                        fill: true,
                        fillColor:{
                            colors: [{
                                opacity: 0.05
                            }, {
                                opacity: 0.01
                            }]
                        }
                    },
                    points: {
                        show: true
                    },
                    shadowSize: 2
                },
                grid:{
                    hoverable: true,
                    clickable: true,
                    tickColor: '#eee',
                    borderWidth: 0
                },
                colors: ["#d12610", "#37b7f3", "#52e136"],
                xaxis:{
                    ticks: dataTicks[1]
                }
            });
        });

        <?php if(isset($_GET['setterNo'])): ?>
            <?php if($_GET['setterNo'] == 'total'): ?>
                $('#total').trigger('click');
            <?php elseif($_GET['setterNo'] == 'avg'): ?>
                $('#avg').trigger('click');
            <?php else: ?>
                $('#<?=$_GET['setterNo']; ?>').trigger('click');
            <?php endif; ?>
        <?php else: ?>
            $('#total').trigger('click');
        <?php endif; ?>

        $("#chart1").bind("plotclick", function (event, pos, item) {
            if (item) {
                if (item.series.label == "&nbsp;baseline"){

                    $("#baseline_date").val(dataPoint[item.dataIndex]);
                    $("#setterNo").val(setter);
                    $(".baselineName").text(ctitle);
                    $("#baseModal").modal({show:true});
                    //alert(" - click point " + dataPoint[item.dataIndex] + " in " + item.series.label);
                }
                plot.highlight(item.series, item.datapoint);
            }
        });

        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 15,
                border: '1px solid #333',
                padding: '4px',
                color: '#fff',
                'border-radius': '3px',
                'background-color': '#333',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        var previousPoint = null;
        
        $("#chart1").bind("plothover", function (event, pos, item) {
            $("#x").text(pos.x.toFixed(2));
            $("#y").text(pos.y.toFixed(2));

            if (item) {
                if (previousPoint != item.dataIndex) {
                    previousPoint = item.dataIndex;
                    $("#tooltip").remove();
                    var x = item.datapoint[0].toFixed(2),
                        y = item.datapoint[1].toFixed(2);
                    showTooltip(item.pageX, item.pageY, item.series.label + " : " + y);
                }
            } else {
                $("#tooltip").remove();
                previousPoint = null;
            }
        });
    });
}(window.jQuery, window, document));
</script>