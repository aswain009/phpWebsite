<?php

$days=5;
$dayArr = array('0'=>'Monday','1'=>'Tuesday','2'=>'Wednesday','3'=>'Thursday','4'=>'Friday');
//echo strtotime('02/18/2015');
if ($_GET['startdate'] && $_GET['setterNo']) {

    $_GET['startdate'] = urldecode($_GET['startdate']);
    $setter = getSetterName($_GET['setterNo']);

    $startdate = date('m/d/Y', strtotime('monday this week', strtotime($_GET['startdate'])));
    $enddate = date('m/d/Y', strtotime('+ 5 days', strtotime($startdate)));
    //$startdate = $_GET['startdate'];
    $cnt =0;
    $thisdate = $startdate;
    while ($cnt <= 4) {

        $thisdate = date('m/d/Y', strtotime('+'.$cnt.' days', strtotime($_GET['startdate'])));
        //echo $thisdate.'<br />';
        $products[$dayArr[$cnt]] = getSetterProd($_GET['setterNo'],$thisdate);
        if ($products[$dayArr[$cnt]]) {
            $setterVals = get_all_setter_data($_GET['setterNo'], $thisdate);
            //print_r($setterVals);
            $products[$dayArr[$cnt]]['Hrs'] = $setterVals['Hrs'];
            $products[$dayArr[$cnt]]['OThrs'] = $setterVals['OThrs'];
            $products[$dayArr[$cnt]]['Base'] = $setterVals['Base'];
            $products[$dayArr[$cnt]]['Qty'] = $setterVals['Qty'];
            $products[$dayArr[$cnt]]['Amt'] = $setterVals['Amt'];
            $products[$dayArr[$cnt]]['Brk'] = $setterVals['Brk'];
            $products[$dayArr[$cnt]]['Bamt'] = $setterVals['Bamt'];
            $products[$dayArr[$cnt]]['AQ'] = $setterVals['AQ'];
            $products[$dayArr[$cnt]]['AA'] = $setterVals['AA'];
            $products[$dayArr[$cnt]]['Total'] = $setterVals['Total'];
        }
        $cnt++;
    }


    //echo '<pre>';
    //print_r($products);
    //echo '</pre>';

}


echo '<h3>'.$setter.' - '.$startdate.' to '.$enddate.'</h3>';
?>
<div class="day-scroll">
<div class="day-row">

        <?php
        foreach($dayArr as $k=> $v) {
            if ($v == 'Thursday') {
                //echo '</div><div class="col-sm-3">';
            }
            echo '<div class="day-block">';
            $tQtySet = 0;
            $tAmtSet = 0;
            $tQtyBk  = 0;
            $tAmtBk  = 0;
            $thisday = $products[$v];
            echo '<h4 class="day-title">'.$v.'</h4><table class="table">';
            echo '<tr><th>SetCode</th><th>QtySet</th><th>AmtSet</th><th>QtyBk</th><th>AmtBk</th></tr>';
            $op = '';
            foreach ($thisday as $k2 => $v2){
                $tQtySet = $tQtySet + $v2['QtySet'];
                $tAmtSet = $tAmtSet + $v2['AmtSet'];
                $tQtyBk  = $tQtyBk + $v2['QtyBk'];
                $tAmtBk  = $tAmtBk + $v2['AmtBk'];
                if (is_numeric($k2)) {
                    echo '<tr><td>' . $v2['SetCode'] . '</td><td>' . $v2['QtySet'] . '</td><td>' . $v2['AmtSet'] . '</td><td>' . $v2['QtyBk'] . '</td><td>' . $v2['AmtBk'] . '</td></tr>';
                } else {
                    $op.= '<tr><th>' . $k2 . '</th><th></th><th class="totalright">' . number_format($thisday[$k2],2) . '</th></tr>';
                }
            }
            if (!$thisday) {
                echo '<tr><td colspan="5">None Found</td></tr>';
            } else {
                echo '<tr><th>Totals</th><th>'.$tQtySet.'</th><th>'.number_format($tAmtSet,2).'</th><th>'.$tQtyBk.'</th><th>'.number_format($tAmtBk,2).'</th></tr>';
            }

            echo '</table>';
            if ($op) {
                echo '<table class="table totaltable">';
                echo $op;
                echo '</table>';
            }
            echo '</div>'."\r\n";
        }


        ?>

</div>
</div>
