<?php require ('autoloader.php');
$setter = new setter\SetProd;
var_dump($setter);