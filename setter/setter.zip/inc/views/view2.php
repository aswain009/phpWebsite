<?php

$days = 5;
$dayArr = array('0'=>'Monday','1'=>'Tuesday','2'=>'Wednesday','3'=>'Thursday','4'=>'Friday');
//echo strtotime('02/18/2015');

if (isset($_GET['startdate']) && isset($_GET['setterNo'])) {

    $_GET['startdate'] = urldecode($_GET['startdate']);
    $setter = getSetterName($_GET['setterNo']);

    $startdate = date('m/d/Y', strtotime('monday this week', strtotime($_GET['startdate'])));
    $enddate = date('m/d/Y', strtotime('+ 5 days', strtotime($startdate)));
    //$startdate = $_GET['startdate'];

    $cnt = 0; //Itterate through the week days from the dayArr array
    $thisdate = $startdate;
    $codeArr = array();
    $products = array();

    while ($cnt <= 4) {

        $thisdate = date('m/d/Y', strtotime('+'.$cnt.' days', strtotime($_GET['startdate'])));
        //echo $thisdate.'<br />';
        $products[$dayArr[$cnt]] = getSetterProd($_GET['setterNo'], $thisdate);
        
        foreach ($products[$dayArr[$cnt]] as $sk => $sval){

            $codeArr[] = $products[$dayArr[$cnt]][$sk]['SetCode'];
        }

        //$codeArr[] = $products[$dayArr[$cnt]]['SetCode']; //old version
        //$codeArr[] = $products[$dayArr[$cnt]]['SetCode']; //new version
        
        if ($products[$dayArr[$cnt]]) {
            $setterVals = get_all_setter_data($_GET['setterNo'], $thisdate);
            //print_r($setterVals);
            $products[$dayArr[$cnt]]['Hrs'] = $setterVals['Hrs'];
            $products[$dayArr[$cnt]]['OThrs'] = $setterVals['OThrs'];
            $products[$dayArr[$cnt]]['Base'] = $setterVals['Base'];
            $products[$dayArr[$cnt]]['Qty'] = $setterVals['Qty'];
            $products[$dayArr[$cnt]]['Amt'] = $setterVals['Amt'];
            $products[$dayArr[$cnt]]['Brk'] = $setterVals['Brk'];
            $products[$dayArr[$cnt]]['Bamt'] = $setterVals['Bamt'];
            $products[$dayArr[$cnt]]['AQ'] = $setterVals['AQ'];
            $products[$dayArr[$cnt]]['AA'] = $setterVals['AA'];
            $products[$dayArr[$cnt]]['Total'] = $setterVals['Total'];
        }
        $cnt++;
    }


    $codeArr = array_filter(array_unique($codeArr));

    //echo '<pre>';
    //print_r($products);
    //print_r($codeArr);
    //echo "resorted
    //";

    $product_resort = array();

    foreach ($dayArr as $k=>$v){
        foreach ($products[$v] as $k2 => $v2) {
            if (is_numeric($k2)) {
                $thiscode = $products[$v][$k2]['SetCode'];
                $product_resort[$v][$thiscode] = $products[$v][$k2];
                //echo 'code: ' . $products[$v][$k2]['SetCode'] . "\n";
            }
        }


    }
    //print_r($product_resort);

    //echo '</pre>';

} else {
    $startdate = date('m/d/Y', strtotime('monday this week'));
    $enddate = date('m/d/Y', strtotime('+ 5 days'));

    $codeArr = array();
    $product_resort = array();
}

echo '<h3>'.$setter.' - '.$startdate.' to '.$enddate.'</h3>';


?>
<div class="day-scroll">
<div class="day-row">
    <table class="table">
        <thead>
            <tr>
                <th></th>
                <th colspan="4" class="dayMonday">Monday</th>
                <th colspan="4" class="dayTuesday">Tuesday</th>
                <th colspan="4" class="dayWednesday">Wednesday</th>
                <th colspan="4" class="dayThursday">Thursday</th>
                <th colspan="4" class="dayFriday">Friday</th>
            </tr>

            <tr>
                <th>SetCode</th>
                <th class="dayMonday">QtySet</th>
                <th class="dayMonday">AmtSet</th>
                <th class="dayMonday">QtyBk</th>
                <th class="dayMonday">AmtBk</th>

                <th class="dayTuesday">QtySet</th>
                <th class="dayTuesday">AmtSet</th>
                <th class="dayTuesday">QtyBk</th>
                <th class="dayTuesday">AmtBk</th>

                <th class="dayWednesday">QtySet</th>
                <th class="dayWednesday">AmtSet</th>
                <th class="dayWednesday">QtyBk</th>
                <th class="dayWednesday">AmtBk</th>

                <th class="dayThursday">QtySet</th>
                <th class="dayThursday">AmtSet</th>
                <th class="dayThursday">QtyBk</th>
                <th class="dayThursday">AmtBk</th>

                <th class="dayFriday">QtySet</th>
                <th class="dayFriday">AmtSet</th>
                <th class="dayFriday">QtyBk</th>
                <th class="dayFriday">AmtBk</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach($codeArr as $code): ?>
            <tr class="code<?=$code; ?>">
                <th><?=$code; ?></th>
                <?php foreach($dayArr as $key => $day): ?>
                    <?php if(isset($product_resort[$day][$code]['QtySet'])): ?>
                        <td class="day<?=$day; ?>"><?=$product_resort[$day][$code]['QtySet']; ?></td>
                    <?php else: ?>
                        <td class="day<?=$day; ?>"></td>
                    <?php endif; ?>

                    <?php if(isset($product_resort[$day][$code]['AmtSet'])): ?>
                        <td class="day<?=$day; ?>"><?=$product_resort[$day][$code]['AmtSet']; ?></td>
                    <?php else: ?>
                        <td class="day<?=$day; ?>"></td>
                    <?php endif; ?>

                    <?php if(isset($product_resort[$day][$code]['QtyBk'])): ?>
                        <td class="day<?=$day; ?>"><?=$product_resort[$day][$code]['QtyBk']; ?></td>
                    <?php else: ?>
                        <td class="day<?=$day; ?>"></td>
                    <?php endif; ?>

                    <?php if(isset($product_resort[$day][$code]['AmtBk'])): ?>
                        <td class="day<?=$day; ?>"><?=$product_resort[$day][$code]['AmtBk']; ?></td>
                    <?php else: ?>
                        <td class="day<?=$day; ?>"></td>
                    <?php endif; ?>

                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table><!--.table-->



    <?php foreach($dayArr as $k=> $v) {
        if ($v == 'Thursday') {
            //echo '</div><div class="col-sm-3">';
        }

        echo '<div class="day-block">';
        $tQtySet = 0;
        $tAmtSet = 0;
        $tQtyBk  = 0;
        $tAmtBk  = 0;
        $thisday = $product_resort[$v];

        echo '<h4 class="day-title">'.$v.'</h4><table class="table">';


        echo '<tr><th>SetCode</th><th>QtySet</th><th>AmtSet</th><th>QtyBk</th><th>AmtBk</th></tr>';
        $op = '';
        foreach ($thisday as $k2 => $v2){
            $tQtySet = $tQtySet + $v2['QtySet'];
            $tAmtSet = $tAmtSet + $v2['AmtSet'];
            $tQtyBk  = $tQtyBk + $v2['QtyBk'];
            $tAmtBk  = $tAmtBk + $v2['AmtBk'];
            //if (is_numeric($k2)) {
                echo '<tr><td>' . $v2['SetCode'] . '</td><td>' . $v2['QtySet'] . '</td><td>' . $v2['AmtSet'] . '</td><td>' . $v2['QtyBk'] . '</td><td>' . $v2['AmtBk'] . '</td></tr>';
            //} else {
            //    $op.= '<tr><th>' . $k2 . '</th><th></th><th class="totalright">' . number_format($thisday[$k2],2) . '</th></tr>';
           // }
        }
        if (!$thisday) {
            echo '<tr><td colspan="5">None Found</td></tr>';
        } else {
            echo '<tr><th>Totals</th><th>'.$tQtySet.'</th><th>'.number_format($tAmtSet,2).'</th><th>'.$tQtyBk.'</th><th>'.number_format($tAmtBk,2).'</th></tr>';
        }

        echo '</table>';
        if ($op) {
            echo '<table class="table totaltable">';
            echo $op;
            echo '</table>';
        }
        echo '</div>'."\r\n";
    }  ?>


</div>
</div>
