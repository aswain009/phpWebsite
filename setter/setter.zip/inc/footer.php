       </div><!--.col-md-12-->
    </div><!--.row-->

</div><!--.container .main-->
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="footer"><strong>Rego Manufacturing</strong> - Custom Built by <a href="http://ohiowebpro.com" target="_blank">Ohio Web Pro Design, LLC</a></p>
        </div><!--.col-md-12-->
    </div><!--.row-->
</div><!--.container-->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/flot/jquery.flot.min.js"></script>
<script src="js/flot/jquery.flot.resize.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!--<script src="js/bootstrap.min.js"></script>-->
<!-- Include custom scripting -->
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>

<script>
<?php if(isset($js)): ?>
<?php echo $js; ?>
<?php endif; ?>
</script>


</body>
</html>