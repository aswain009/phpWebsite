<div class="container main">
    <div class="row header">
        <div class="col-xs-4">
            <?php if(isset($_GET['column'])): ?>
                <h3 class="data-header">Data: <?php echo $_GET['column'];?></h3>
            <?php else: ?>
                <h3 class="data-header">Data:</h3>
            <?php endif; ?>
        </div><!--.col-xs-4-->
        <div class="col-xs-8">
            <ul class="nav nav-pills pull-right ">

                <li role="presentation" class="<?=$active1; ?>"><a href="/index.php">All</a></li>
                <li role="presentation" class="<?=$active2; ?>"><a href="/individual.php">Individual</a></li>
                <li role="presentation" class="<?=$active3; ?>"><a href="/code.php">Code</a></li>

            </ul><!--.nav-pills-->
        </div><!--.col-xs-8-->
    </div><!--.header-->
    <div class="row">
        <div class="col-md-12">