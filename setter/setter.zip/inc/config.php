<?php
#### DATABASE CONFIG OPTIONS ###################
//define('DB_NAME', 'SetterData');
define('DB_NAME', 'regosetter');

//define('DB_USER', 'Nick');
define('DB_USER', 'root');

//define('DB_PASSWORD', '#n1ckw0rk54r3g0!');
define('DB_PASSWORD', '');

//define('DB_HOST', 'localhost');
define('DB_HOST', 'localhost');

define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');