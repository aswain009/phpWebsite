<?php

#### REGO FUNCTIONS #########################


function get_setters() {
    global $pdo;
    $array = array();
    $sql = 'SELECT * FROM Setter ORDER BY Name ASC ';

    $stm = $pdo->prepare($sql);
    $stm->execute();
    while ($data = $stm->fetch()) {
        $array[$data['SetterNo']] = $data['Name'];
    }
    return $array;

}
function getSetterName($setterNo) {
    global $pdo;

    $sql = "SELECT Name FROM Setter WHERE SetterNo = '".$setterNo."' LIMIT 1 ";
    $stm = $pdo->prepare($sql);
    $stm->execute();
    $data = $stm->fetch();
    return $data['Name'];
}

function getSetterProd($setter, $date) {
    $date = date('Y-m-d h:i:s',strtotime(urldecode($date)));
    global $pdo;

    $start = date('Y-m-d 00:00:00',strtotime(urldecode($date)));
    $end = date('Y-m-d 23:59:59',strtotime(urldecode($date)));

    $array = array();
    $sql = "SELECT * FROM SetProd WHERE SetterNo='".$setter."' and SetDate >= '".$start ."' AND SetDate <= '".$end ."' ";
    //echo $sql.'<br /> start:'.$start.' end:'.$end;
    $stm = $pdo->prepare($sql);
    $stm->execute();
    while ($data = $stm->fetch()) {
        $array[] = $data;
    }
    return $array;
}

function setBase($setterNo,$Date,$Base) {
    if ($setterNo && $Date && $Base ) {
        if (is_numeric($Base)) {
            $Date = date('Y-m-d h:i:s', strtotime($Date));
            global $pdo;
            $statement = $pdo->prepare("INSERT INTO BaseLine (SetterNo, Base, Date) VALUES(:SetterNo, :Base, :Date)");
            $input = array(
                "SetterNo" => $setterNo,
                "Base" => $Base,
                "Date" => $Date
            );
            if ($statement->execute($input)) {
                return '<div class="alert alert-success" role="alert">Baseline data saved.</div>';
            } else {
                return '<div class="alert alert-danger" role="alert">Error saving Baseline.</div>';
            }
        } else {
            return '<div class="alert alert-danger" role="alert">Baseline Must be a number.</div>';
        }
    } else {
        return '<div class="alert alert-danger" role="alert">Missing Data.</div>';
    }


}
function get_7days_later($day) {
    $time = strtotime($day);
    $time = $time + 518400;
    return date('m/d/Y',$time);
}

function get_week_before($startdate) {
    $range = array();
    $range['firstday'] = date('Y-m-d 00:00:00',strtotime('-7 day',strtotime($startdate))); //Last week monday
    $range['lastday'] =  date('Y-m-d 00:00:00',strtotime('-1 day',strtotime($startdate))); //this week sunday

    //var_dump($range); echo '<br/>';
    //echo $range['firstday'].'<br />';
    return $range;
}
function get_month_before($startdate) {
    $range = array();
    $range['firstday'] = date('Y-m-d 00:00:00',strtotime('-1 month',strtotime($startdate)));
    $range['lastday'] =  date('Y-m-d 00:00:00',strtotime('-1 day',strtotime($startdate)));

    return $range;
}
function get_setter_data($start, $end, $SetterNo, $column = 'Total') {
    global $pdo;
    $total = 0;
    $hours = 0;
    $DailyHrs = 0;
    $AdjDailyBase = 0;
    $Amt = 0;

    //vaR_dump($start.' '.$end);
    
    //$sql = "SELECT * FROM SetBase WHERE Date >= '" . $start . "' AND Date < '" . $end . "' AND SetterNo = '" . $SetterNo . "' ";

    $sql = 'SELECT * FROM SetBase WHERE Date >= :startDate AND Date < :endDate AND SetterNo = :setterNo';

    try{
        $stm = $pdo->prepare($sql);
        $stm->bindValue(':startDate', $start);
        $stm->bindValue(':endDate', $end);
        $stm->bindValue(':setterNo', $SetterNo);
        $stm->execute();    
    } catch (Exception $e){
        var_dump($e->getMessage());
        die();
    }

    //Accumulate all of the date rows for the period
    foreach($stm->fetchAll() as $data){
        //echo '<pre>';
        //var_dump($data);
        //echo '</pre>';
        $hours = $hours + $data['Hrs'];
        $total = $total + $data[$column];
        $DailyHrs =  $data['DailyHrs'];
        $AdjDailyBase =  $data['AdjDailyBase'];
        $Amt = $data['Amt'];
        //echo $DailyHrs;
    }
    //die();

    /* while ($data = $stm->fetch()) {

        $hours = $hours + $data['Hrs'];
        $total = $total + $data[$column];
        $DailyHrs =  $data['DailyHrs'];
        $AdjDailyBase =  $data['AdjDailyBase'];
        //echo $DailyHrs;
    }*/

    if ($column == 'Total') {
        $dataArr = array(
            //'data' => number_format($total, 0,'.',''),
            'data' => number_format($total, 2,'.',''),
            'Hrs' => $hours,
            'DailyHrs' => $DailyHrs,
            'AdjDailyBase' => $AdjDailyBase,
            'Amt' => $Amt,
        );
    } else {
        $dataArr = array(
            'data' => number_format($total, 2,'.',''),
            'Hrs' => $hours,
            'DailyHrs' => $DailyHrs,
            'AdjDailyBase' => $AdjDailyBase,
            'Amt' => $Amt,
        );
    }

    return $dataArr;
}
function get_all_setter_data($SetterNo,$date) {
    $date = date('Y-m-d h:i:s',strtotime(urldecode($date)));
    global $pdo;
    $start = date('Y-m-d 00:00:00',strtotime(urldecode($date)));
    $end = date('Y-m-d 23:59:59',strtotime(urldecode($date)));

    //$sql = "SELECT * FROM SetBase WHERE Date >= '".$start."' AND Date < '".$end."' AND SetterNo = '".$SetterNo."' ";
    $sql = 'SELECT Hrs, OThrs, Base, Qty, Amt, Brk, Bamt, AQ, AA, Total FROM SetBase WHERE Date >= :startDate AND Date < :endDate AND SetterNo = :setterNo';

    $stm = $pdo->prepare($sql);
    $stm->bindValue(':startDate', $start);
    $stm->bindValue(':endDate', $end);
    $stm->bindValue(':setterNo', $SetterNo);
    $stm->execute();

    /*
    while ($data = $stm->fetch()) {
        foreach ($data as $k => $v) {
            echo '<h1>'.$k.'</h1>';
            echo '<h2>'.$v.'</h2>';
            ${$k} = ${$k} + $v;
        }
    }

    echo '<hr/>';
    $totals = array('Hrs'=>$Hrs,'OThrs'=>$OThrs,'Base'=>$Base,'Qty'=>$Qty,'Amt'=>$Amt,'Brk'=>$Brk,'Bamt'=>$Bamt, 'AQ'=>$AQ,'AA'=>$AA,'Total'=>$Total);
    return $totals;
    */

    $totals = array();
    while($data = $stm->fetch()){
        foreach($data as $key => $value){
            $totals[$key] = $value;
        }
    }

    return $totals;
}


function get_setter_baseline ($start,$end,$SetterNo) {
    global $pdo;
    $sql = "SELECT * FROM BaseLine WHERE Date <= '".$start."' AND SetterNo = '".$SetterNo."' ORDER BY Date DESC,ID DESC LIMIT 1 ";
    // = "SELECT * FROM BaseLine WHERE Date >= '".$start."' AND Date < '".$end."' AND SetterNo = '".$SetterNo."' ORDER BY Date DESC LIMIT 1 ";
    $stm = $pdo->prepare($sql);
    $stm->execute();
    $data = $stm->fetch();
    if (!$data) {
        $sql = "SELECT * FROM BaseLine WHERE Date <= '".$start."' AND SetterNo = '".$SetterNo."' ORDER BY Date DESC LIMIT 1 ";
        $stm = $pdo->prepare($sql);
        $stm->execute();
        $data = $stm->fetch();
        return $data['Base'];
    } else {
        return $data['Base'];
    }


}