<?php
namespace setter;

class SetProd{
	private $RecID;
	private $SetterNo;
	private $SetDate;
	private $SetCode;
	private $Desc;
	private $CodeType;
	private $QtySet;
	private $AmtSet;
	private $QtyBk;
	private $AmtBk;

	public function getRecID(){
		return $this->RecID;
	}
	
	public function setRecID($value){
		$this->RecID = $value;
	}
	
	public function getSetterNo(){
		return $this->SetterNo;
	}
	
	public function setSetterNo($value){
		$this->SetterNo = $value;
	}
	
	public function getSetDate(){
		return $this->SetDate;
	}
	
	public function setSetDate($value){
		$this->SetDate = $value;
	}
	
	public function getSetCode(){
		return $this->SetCode;
	}
	
	public function setSetCode($value){
		$this->SetCode = $value;
	}

	public function getDesc(){
		return $this->Desc;
	}

	public function setDesc($value){
		$this->Desc = $value;
	}

	public function getCodeType(){
		return $this->CodeType;
	}

	public function setCodeType($value){
		$this->CodeType = $value;
	}
	
	public function getQtySet(){
		return $this->QtySet;
	}
	
	public function setQtySet($value){
		$this->QtySet = $value;
	}
	
	public function getAmtSet(){
		return $this->AmtSet;
	}
	
	public function setAmtSet($value){
		$this->AmtSet = $value;
	}
	
	public function getQtyBk(){
		return $this->QtyBk;
	}
	
	public function setQtyBk($value){
		$this->QtyBk = $value;
	}
	
	public function getAmtBk(){
		return $this->AmtBk;
	}
	
	public function setAmtBk($value){
		$this->AmtBk = $value;
	}

	public static function readAll(){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM SetProd';
		try{
			$query = $pdo->prepare($sql);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		return $query->fetchAll();
	}

	public static function readByID($value){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM SetProd WHERE RecID = :RecID';
		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':RedID', $value);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		return $query->fetch();
	}

	public static function readBySetter(Setter $setter){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM SetProd WHERE SetterNo = :SetterNo';
		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':SetterNo', $setter->getSetterNo());
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		return $query->fetchAll();
	}

	public static function readBySetterDateRange(Setter $setter, $start, $end){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM SetProd WHERE SetterNo = :setter AND SetDate >= :startDate AND SetDate <= :endDate';
		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':setter', $setter->getSetterNo());
			$query->bindValue(':startDate', $start);
			$query->bindValue(':endDate', $end);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		if($query->rowCount() > 0){
			return $query->fetchAll();
		} else {
			return false;
		}

		
	}

	public static function readAllCodes(){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT DISTINCT SetCode, CodeType FROM SetProd ORDER BY CodeType';
		try{
			$query = $pdo->prepare($sql);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_ASSOC);

		return $query->fetchAll();
	}
}
