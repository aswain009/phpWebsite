<?php
namespace setter;

class Setter{
	private $SetterNo;
	private $Name;
	
	public function getSetterNo(){
		return $this->SetterNo;
	}

	public function setSetterNo($value){
		$this->SetterNo = $value;
	}

	public function getName(){
		return $this->Name;
	}

	public function setName($value){
		$this->Name = $value;
	}

	public static function readByID($value){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM Setter WHERE SetterNo = :SetterNo';
		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':SetterNo', $value);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		return $query->fetch();
	}

	public static function readAll(){
		global $pdo;
		$pdo->beginTransaction();

		$sql = 'SELECT * FROM Setter ORDER BY Name ASC';
		try{
			$query = $pdo->prepare($sql);
			$query->execute();
		} catch(Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();

		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		return $query->fetchAll();
	}
}