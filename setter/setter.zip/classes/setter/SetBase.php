<?php
namespace setter;

class SetBase{
	private $ReciD;
	private $Date;
	private $SetterNo;
	private $Hrs;
	private $OThrs;
	private $Base;
	private $Qty;
	private $Amt;
	private $Brk;
	private $Bamt;
	private $AQ;
	private $AA;
	private $Total;
	private $DailyHrs;
	private $AdjBase;
	private $AdjDailyBase;

	public function getReciD(){
		return $this->ReciD;
	}

	public function setReciD($value){
		$this->ReciD = $value;
	}

	public function getDate(){
		return $this->Date;
	}

	public function setDate($value){
		$this->Date = $value;
	}

	public function getSetterNo(){
		return $this->SetterNo;
	}

	public function setSetterNo($value){
		$this->SetterNo = $value;
	}

	public function getHrs(){
		return $this->Hrs;
	}

	public function setHrs($value){
		$this->Hrs = $value;
	}

	public function getOThrs(){
		return $this->OThrs;
	}

	public function setOThrs($value){
		$this->OThrs = $value;
	}

	public function getBase(){
		return $this->Base;
	}

	public function setBase($value){
		$this->Base = $value;
	}

	public function getQty(){
		return $this->Qty;
	}

	public function setQty($value){
		$this->Qty = $value;
	}

	public function getAmt(){
		return $this->Amt;
	}

	public function setAmt($value){
		$this->Amt = $value;
	}

	public function getBrk(){
		return $this->Brk;
	}

	public function setBrk($value){
		$this->Brk = $value;
	}

	public function getBamt(){
		return $this->Bamt;
	}

	public function setBamt($value){
		$this->Bamt = $value;
	}

	public function getAQ(){
		return $this->AQ;
	}

	public function setAQ($value){
		$this->AQ = $value;
	}

	public function getAA(){
		return $this->AA;
	}

	public function setAA($value){
		$this->AA = $value;
	}

	public function getTotal(){
		return $this->Total;
	}

	public function setTotal($value){
		$this->Total = $value;
	}

	public function getDailyHrs(){
		return $this->DailyHrs;
	}

	public function setDailyHrs($value){
		$this->DailyHrs = $value;
	}

	public function getAdjBase(){
		return $this->AdjBase;
	}

	public function setAdjBase($value){
		$this->AdjBase = $value;
	}

	public function getAdjDailyBase(){
		return $this->AdjDailyBase;
	}

	public function setAdjDailyBase($value){
		$this->AdjDailyBase = $value;
	}

	public static function readPeriod($setterID, $period, $periodType = 'Weekly', $startDate = null){
		global $pdo;
		$pdo->beginTransaction();

		//If no date, set a default
		if(!isset($startDate)){
			$startDate = date('m/d/Y');
		}

		//echo '<h3>'.$startDate.'</h3>';
		//echo '<h3>'.$setterID.'</h3>';
		//echo '<h3>'.$period.'</h3>';
		//echo '<h3>'.$periodType.'</h3>';

		$startDateObj = \DateTime::createFromFormat('m/d/Y', $startDate);
		$endDateObj = \DateTime::createFromFormat('m/d/Y', $startDate);

		//Make modifications based on the period type (weekly or monthly)
		if($periodType == 'Monthly'){
			$startDateObj->modify('first day of this month'); //Change to the first day of the month
			$endDateObj->modify('last day of this month');

			//Iterate any periods of the month
			for($m = 0; $m < $period; $m++){
				$startDateObj->modify('first day of last month');
				$endDateObj->modify('last day of last month');
			}
		} else { //Weekly or blank
			$startDateObj->modify('monday this week');
			$endDateObj->modify('saturday this week');

			//Iterate any periods of the week
			for($w = 0; $w < $period; $w++){
				$startDateObj->modify('last monday');
				$endDateObj->modify('last saturday');
			}
		}

		//var_dump($period); echo '<br/>';
		//var_dump($startDateObj); echo '<br/>';
		//var_dump($endDateObj); echo '<br/>';
		//echo '<hr/>';

		//This will get data from a span of a week or a month for a specific setter
		$sql = 'SELECT * FROM SetBase WHERE setterNo = :setterNo AND Date >= :startDate AND Date < :endDate';

		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':setterNo', $setterID, \PDO::PARAM_INT);
			$query->bindValue(':startDate', $startDateObj->format('Y-m-d'));
			$query->bindValue(':endDate', $endDateObj->format('Y-m-d'));
			$query->execute();
		} catch (Exception $e){
			$pdo->rollBack();
			var_dump($e->getMessage());
			return false;
		}

		$pdo->commit();
		$query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

		if($query->rowCount() > 0){
			return $query->fetchAll();	
		} else {
			//Still return an array of at least one empty object
			$return[] = new SetBase;
			return $return;
		}	
	}

	public static function readData($setterID, $start, $end, $column = 'Total'){
		global $pdo;
		$pdo->beginTransaction();

		//Initialize variables
		$regularHours = 0;
		$columnTotal = 0;
		$dailyHours = 0;
		$adjDailyBase = 0;

		$sql = 'SELECT * FROM SetBase WHERE Date >= :startDate AND Date < :endDate AND SetterNo = :setterID';

		try{
			$query = $pdo->prepare($sql);
			$query->bindValue(':startDate', $start);
        	$query->bindValue(':endDate', $end);
        	$query->bindValue(':setterID', $setterID);
        	$query->execute(); 
		} catch (Exception $e){
			$pdo->rollBack();
	        var_dump($e->getMessage());
	        die();
	    }

	    $pdo->commit();

	    $query->setFetchMode(\PDO::FETCH_CLASS, __CLASS__);

	    $results = $query->fetchAll();

	    foreach($results as $dateRow){
	    	$regularHours = $regularHours + $dateRow->getHrs();
	    	$columnTotal = $columnTotal + $dateRow->{'get'.$column}(); //Accumulate the column total
	    	$dailyHours = $dailyHours + $dateRow->getDailyHrs();
	    	$adjDailyBase = $adjDailyBase + $dateRow->getAdjDailyBase();
	    }

	    $return = new \stdClass();
	    $return->regularHours = $regularHours; //originally 'Hrs'
	    $return->columnTotal = $columnTotal; //originally 'data'
	    $return->dailyHours = $dailyHours; //originally 'DailyHrs'
	    $return->adjDailyBase = $adjDailyBase; //originally 'AdjDailyBase'

	    return $return;
	}
}